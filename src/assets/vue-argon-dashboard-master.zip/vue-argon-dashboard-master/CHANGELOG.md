## [2.0.0] - 2021-02-22
### Vue 3 Update
- Compatibility with new Vuejs 3

## [1.1.1] - 2020-11-25
- Change broken links

## [1.1.0] - 2020-06-30
- Package updates

## [1.0.0] - 2019-04-07
### Initial Release
